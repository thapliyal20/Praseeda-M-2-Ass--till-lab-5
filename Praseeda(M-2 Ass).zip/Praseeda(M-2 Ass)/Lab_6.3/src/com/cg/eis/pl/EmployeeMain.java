package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class EmployeeMain {
	
	public static void main(String[] args)throws EmployeeException {
	Employee emp= new Employee();
	Scanner sc=new Scanner(System.in);
	EmpServiceImp emps=new EmpServiceImp();
		System.out.println("Enter the employee ID: ");
		int empId=sc.nextInt();
		
		System.out.println("Enter the employee name: ");
		String empName=sc.next();
		
		System.out.println("Enter the employee Designation: ");
		String empDesgn=sc.next();
	  
		System.out.println("Enter the employee Salary: ");
		float empSal=sc.nextFloat();
		sc.nextLine();
		try {
			if(empSal<3000)
			{
				throw new EmployeeException("Salary should be more than 3000");
			}
			else 
			{
				emp=new Employee(empId,empName,empSal,empDesgn);
				System.out.println(emps.getInsuranceScheme(emp));
				System.out.println(emps.displayEmpInfo(emp,emps.getInsScheme()));
			
			}
		} catch (EmployeeException e) {
			System.out.println(e);
		}

				
	sc.close();
}
}
