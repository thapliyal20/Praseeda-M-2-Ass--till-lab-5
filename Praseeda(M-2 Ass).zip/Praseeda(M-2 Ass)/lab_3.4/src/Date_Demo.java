import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class Date_Demo {
	private String date1;
	private String date2;
	

	public Date_Demo() {
	}

	public Date_Demo(String date1, String date2) {
	this.date1 = date1;
		this.date2 = date2;
	}

	public void calcDuration()
	{
		DateTimeFormatter myFormatter=DateTimeFormatter.ofPattern("yyyy-MMM-dd");
		LocalDate myNewDate1= LocalDate.parse(date1, myFormatter);
		LocalDate myNewDate2= LocalDate.parse(date2, myFormatter);
		Period per= Period.between(myNewDate1, myNewDate2);
		System.out.println(+per.getDays()+" Days "+per.getMonths()+" Months "+per.getYears()+" Years");

	}

}
