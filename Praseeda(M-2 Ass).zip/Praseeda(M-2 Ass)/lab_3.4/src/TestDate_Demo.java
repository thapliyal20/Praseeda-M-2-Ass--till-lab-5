
import java.util.Scanner;


public class TestDate_Demo {
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your Date1 like '2017-Jan-01':");
		String date1=sc.next();
		
		System.out.println("Enter your Date2 like '2017-Jan-01':");
		String date2= sc.next();
		
		Date_Demo myDates= new Date_Demo(date1, date2);
		myDates.calcDuration();
		sc.close();
	}
}
