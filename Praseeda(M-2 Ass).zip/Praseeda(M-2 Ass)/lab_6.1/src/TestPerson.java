import java.util.Scanner;



public class TestPerson{

	public static void main(String[] args)  throws PersonException{
		Person per=new Person();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the First Name: ");
		String firstName=sc.nextLine();
		
		System.out.println("Enter the Last Name: ");
		String lastName=sc.nextLine();
		
		System.out.println("Enter the Gender: ");
		char gender=sc.next().charAt(0);
		
		try {
			if(firstName.isEmpty() && lastName.isEmpty())
			{
				throw new PersonException("Names should not be blank");
			}
			else
			{
				per.setFirstName(firstName);
				per.setLastName(lastName);
				per.setGender(gender);
			}
		} catch (PersonException e) {
			System.out.println(e);
		}
		
		System.out.println(" " + per.dispDetails());
		System.out.println(" " + per.dispPersonDetails());
		sc.close();
	}

}