
public class Person {
	private String firstName;
	private String lastName;
	char gender;
	
	
	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}

	public String dispPersonDetails() {
		return "Person Details:\n-----------------------\nFull Name:" + firstName + " " + lastName
				+ "\nGender:" + gender;
	}


	public String dispDetails() {
		return "Person Details:\n-----------------------\nFirst Name:" + firstName + "\nLast Name:" + lastName
				+ "\nGender:" + gender;
	}		
}



